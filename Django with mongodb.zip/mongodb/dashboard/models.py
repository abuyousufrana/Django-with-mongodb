from django.db import models
from django.utils.safestring import mark_safe

# Create your models here.
class Manufacturer(models.Model):
    designer_id = models.AutoField(auto_created=True, primary_key = True)
    name = models.CharField(max_length=300)
    street_address = models.CharField(max_length=300, null=True)
    city = models.CharField(max_length=300, null=True)
    zip = models.CharField(max_length=300, null=True)
    phone = models.CharField(max_length=300, null=True)

    # def __str__(self):
    #     return self.designer_id



class Customer(models.Model):
    customer_id = models.AutoField(auto_created=True, primary_key = True)
    name = models.CharField(max_length=300)
    street_address = models.CharField(max_length=300, null=True)
    city = models.CharField(max_length=300, null=True)
    state = models.CharField(max_length=300, null=True)
    zip = models.CharField(max_length=300, null=True)
    phone = models.CharField(max_length=300, null=True)

    # def __str__(self):
    #     return self.customer_id


    

class Part(models.Model):
    part_id = models.AutoField(auto_created=True, primary_key = True)
    name = models.CharField(max_length=300)
    description = models.CharField(max_length=300, null=True)
    designer_id  = models.ForeignKey(Manufacturer, on_delete=models.RESTRICT)

    # def __str__(self):
    #     return self.part_id
    
class Order(models.Model):
    order_id = models.AutoField(auto_created=True, primary_key = True)
    part_id  = models.ForeignKey(Part, on_delete=models.RESTRICT)
    customer_id  = models.ForeignKey(Customer, on_delete=models.RESTRICT)
    quantity = models.CharField(max_length=300, null=True)
    repeat_no = models.CharField(max_length=300, null=True)
    phone = models.CharField(max_length=300, null=True)
    