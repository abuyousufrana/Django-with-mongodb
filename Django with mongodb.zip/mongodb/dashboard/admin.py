from django.contrib import admin
from .models import Car

class CarAdmin(admin.ModelAdmin):
    list_display = ('name', 'street_address', 'city', 'zip', 'phone',)
   

# class CustomersAdmin(admin.ModelAdmin):
#     pass


# class PartsAdmin(admin.ModelAdmin):
#     pass

admin.site.register(Car, CarAdmin)
# admin.site.register(Customers, CustomersAdmin)
# admin.site.register(Parts, PartsAdmin)
