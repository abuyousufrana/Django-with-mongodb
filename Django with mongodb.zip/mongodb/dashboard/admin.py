from django.contrib import admin
from dashboard.models import Manufacturer, Customer, Part, Order


   

class ManufacturerAdmin(admin.ModelAdmin):
    list_display = ('name', 'street_address', 'city',)

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'street_address', 'city',)

class PartAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'designer_id',)

class OrderAdmin(admin.ModelAdmin):
    list_display = ('part_id', 'customer_id', 'quantity',)

admin.site.register(Manufacturer, ManufacturerAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(Part, PartAdmin)
admin.site.register(Order, OrderAdmin)

